# Wolfenstein-3D-Clone
Wolfenstein 3D using OpenGL

Wolfeinstein 3D clone written in Python using Pygame, ModernGL, Numpy, PyTMX, PyGLM

You can create your own level in the Tiled editor, see more details here:
https://youtu.be/yJXuvK_eLrQ?si=ShmzXXb1uSqtDC4u

![wolfenstein](/screenshot/0.jpg)


![wolfenstein](/screenshot/1.jpg)