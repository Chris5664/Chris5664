<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="sprite_sheet" tilewidth="256" tileheight="256" tilecount="81" columns="9">
 <image source="../../assets/sprite_sheet/sprite_sheet.png" width="2304" height="2304"/>
</tileset>
